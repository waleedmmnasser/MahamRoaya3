<?php

class ForTest extends Controller
{
    public function index()
    {
        echo "From fortest index";
    }

    public function another()
    {
        echo "From fortest another";
    }
}