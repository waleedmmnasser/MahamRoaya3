<h1>صفحة المهام</h1>
<br>
<label>المهام الحالية</label>
<table>
    <thead>
        <tr>وصف المهمة</tr>
        <tr>تاريخ التكليف</tr>
        <tr>التاريخ المحدد للتسليم</tr>
        <tr>نسبة الإنجاز</tr>
        <tr>ملاحظات</tr>
    </thead>
    <tbody id="tasksTblBody"></tbody>
</table>


