</div>

<div id="footer">
    مؤسسة رؤية للفكر والثقافة -- 2018
</div>

</body>
</html>